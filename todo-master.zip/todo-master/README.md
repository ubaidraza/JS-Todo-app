# To-do
A simple todo list app built in HTML, CSS and JavaScript.

If you want to learn how to build this yourself you can check out the YouTube video that walks through the whole process here:
- [Learn to code a to-do list app in JavaScript - Part 1](https://www.youtube.com/watch?v=2wCpkOk2uCg)
- [Learn to code a to-do list app in JavaScript - Part 2](https://www.youtube.com/watch?v=bGLZ2pwCaiI)

## License
[MIT](LICENSE.md) © [Max Sandelin](https://instagram.com/themaxsandelin)
